﻿
namespace projCalcularMedia
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblTituloMedia = new System.Windows.Forms.Label();
            this.lblPrimeiroNumero = new System.Windows.Forms.Label();
            this.lblSegundoNumero = new System.Windows.Forms.Label();
            this.lblTerceiroNumero = new System.Windows.Forms.Label();
            this.lblQuartoNumero = new System.Windows.Forms.Label();
            this.txtPrimeiroNumero = new System.Windows.Forms.TextBox();
            this.txtSegundoNumero = new System.Windows.Forms.TextBox();
            this.txtTerceiroNumero = new System.Windows.Forms.TextBox();
            this.txtQuartoNumero = new System.Windows.Forms.TextBox();
            this.btnCalcularMedia = new System.Windows.Forms.Button();
            this.lblInsiraNumeros = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Highlight;
            this.panel1.Controls.Add(this.lblTituloMedia);
            this.panel1.Location = new System.Drawing.Point(1, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(389, 119);
            this.panel1.TabIndex = 0;
            // 
            // lblTituloMedia
            // 
            this.lblTituloMedia.AutoSize = true;
            this.lblTituloMedia.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F);
            this.lblTituloMedia.ForeColor = System.Drawing.Color.White;
            this.lblTituloMedia.Location = new System.Drawing.Point(103, 46);
            this.lblTituloMedia.Name = "lblTituloMedia";
            this.lblTituloMedia.Size = new System.Drawing.Size(192, 26);
            this.lblTituloMedia.TabIndex = 0;
            this.lblTituloMedia.Text = "Calcule sua média";
            // 
            // lblPrimeiroNumero
            // 
            this.lblPrimeiroNumero.AutoSize = true;
            this.lblPrimeiroNumero.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lblPrimeiroNumero.Location = new System.Drawing.Point(106, 200);
            this.lblPrimeiroNumero.Name = "lblPrimeiroNumero";
            this.lblPrimeiroNumero.Size = new System.Drawing.Size(83, 18);
            this.lblPrimeiroNumero.TabIndex = 1;
            this.lblPrimeiroNumero.Text = "1º Número:";
            // 
            // lblSegundoNumero
            // 
            this.lblSegundoNumero.AutoSize = true;
            this.lblSegundoNumero.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lblSegundoNumero.Location = new System.Drawing.Point(106, 234);
            this.lblSegundoNumero.Name = "lblSegundoNumero";
            this.lblSegundoNumero.Size = new System.Drawing.Size(83, 18);
            this.lblSegundoNumero.TabIndex = 2;
            this.lblSegundoNumero.Text = "2º Número:";
            // 
            // lblTerceiroNumero
            // 
            this.lblTerceiroNumero.AutoSize = true;
            this.lblTerceiroNumero.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lblTerceiroNumero.Location = new System.Drawing.Point(106, 269);
            this.lblTerceiroNumero.Name = "lblTerceiroNumero";
            this.lblTerceiroNumero.Size = new System.Drawing.Size(83, 18);
            this.lblTerceiroNumero.TabIndex = 3;
            this.lblTerceiroNumero.Text = "3º Número:";
            // 
            // lblQuartoNumero
            // 
            this.lblQuartoNumero.AutoSize = true;
            this.lblQuartoNumero.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lblQuartoNumero.Location = new System.Drawing.Point(106, 306);
            this.lblQuartoNumero.Name = "lblQuartoNumero";
            this.lblQuartoNumero.Size = new System.Drawing.Size(83, 18);
            this.lblQuartoNumero.TabIndex = 4;
            this.lblQuartoNumero.Text = "4º Número:";
            // 
            // txtPrimeiroNumero
            // 
            this.txtPrimeiroNumero.Location = new System.Drawing.Point(195, 201);
            this.txtPrimeiroNumero.Name = "txtPrimeiroNumero";
            this.txtPrimeiroNumero.Size = new System.Drawing.Size(100, 20);
            this.txtPrimeiroNumero.TabIndex = 5;
            // 
            // txtSegundoNumero
            // 
            this.txtSegundoNumero.Location = new System.Drawing.Point(195, 232);
            this.txtSegundoNumero.Name = "txtSegundoNumero";
            this.txtSegundoNumero.Size = new System.Drawing.Size(100, 20);
            this.txtSegundoNumero.TabIndex = 6;
            // 
            // txtTerceiroNumero
            // 
            this.txtTerceiroNumero.Location = new System.Drawing.Point(195, 267);
            this.txtTerceiroNumero.Name = "txtTerceiroNumero";
            this.txtTerceiroNumero.Size = new System.Drawing.Size(100, 20);
            this.txtTerceiroNumero.TabIndex = 7;
            // 
            // txtQuartoNumero
            // 
            this.txtQuartoNumero.Location = new System.Drawing.Point(195, 306);
            this.txtQuartoNumero.Name = "txtQuartoNumero";
            this.txtQuartoNumero.Size = new System.Drawing.Size(100, 20);
            this.txtQuartoNumero.TabIndex = 8;
            // 
            // btnCalcularMedia
            // 
            this.btnCalcularMedia.Location = new System.Drawing.Point(158, 366);
            this.btnCalcularMedia.Name = "btnCalcularMedia";
            this.btnCalcularMedia.Size = new System.Drawing.Size(75, 23);
            this.btnCalcularMedia.TabIndex = 9;
            this.btnCalcularMedia.Text = "Calcular";
            this.btnCalcularMedia.UseVisualStyleBackColor = true;
            this.btnCalcularMedia.Click += new System.EventHandler(this.btnCalcularMedia_Click);
            // 
            // lblInsiraNumeros
            // 
            this.lblInsiraNumeros.AutoSize = true;
            this.lblInsiraNumeros.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.lblInsiraNumeros.Location = new System.Drawing.Point(125, 145);
            this.lblInsiraNumeros.Name = "lblInsiraNumeros";
            this.lblInsiraNumeros.Size = new System.Drawing.Size(159, 24);
            this.lblInsiraNumeros.TabIndex = 1;
            this.lblInsiraNumeros.Text = "Insira os números";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(195, 350);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 13);
            this.label2.TabIndex = 11;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(390, 450);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblInsiraNumeros);
            this.Controls.Add(this.btnCalcularMedia);
            this.Controls.Add(this.txtQuartoNumero);
            this.Controls.Add(this.txtTerceiroNumero);
            this.Controls.Add(this.txtSegundoNumero);
            this.Controls.Add(this.txtPrimeiroNumero);
            this.Controls.Add(this.lblQuartoNumero);
            this.Controls.Add(this.lblTerceiroNumero);
            this.Controls.Add(this.lblSegundoNumero);
            this.Controls.Add(this.lblPrimeiroNumero);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblTituloMedia;
        private System.Windows.Forms.Label lblPrimeiroNumero;
        private System.Windows.Forms.Label lblSegundoNumero;
        private System.Windows.Forms.Label lblTerceiroNumero;
        private System.Windows.Forms.Label lblQuartoNumero;
        private System.Windows.Forms.TextBox txtPrimeiroNumero;
        private System.Windows.Forms.TextBox txtSegundoNumero;
        private System.Windows.Forms.TextBox txtTerceiroNumero;
        private System.Windows.Forms.TextBox txtQuartoNumero;
        private System.Windows.Forms.Button btnCalcularMedia;
        private System.Windows.Forms.Label lblInsiraNumeros;
        private System.Windows.Forms.Label label2;
    }
}

