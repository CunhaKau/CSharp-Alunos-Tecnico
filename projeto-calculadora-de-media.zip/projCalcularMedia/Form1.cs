﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projCalcularMedia
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcularMedia_Click(object sender, EventArgs e)
        {
            float soma, media, valor;
            soma = 0;
            foreach(Control controle in this.Controls)
            {
                if(controle is TextBox)
                {
                    valor = Convert.ToSingle(((TextBox)controle).Text);
                    soma += valor;
                    ((TextBox)controle).Text = "";
                }
            }
                media = soma / 4;
                

                MessageBox.Show("A média é: " + media.ToString(), "Resultado da Média", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
               

            
        }

    }
}
